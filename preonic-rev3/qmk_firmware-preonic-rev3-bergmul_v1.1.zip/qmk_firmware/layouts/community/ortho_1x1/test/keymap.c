#include QMK_KEYBOARD_H

/* This keyboard/layout is used to test community layout discovery/compilation. */

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    LAYOUT_ortho_1x1(KC_B)
};
