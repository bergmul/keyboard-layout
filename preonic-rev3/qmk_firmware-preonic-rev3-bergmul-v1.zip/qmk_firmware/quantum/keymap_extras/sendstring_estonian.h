/* Copyright 2020
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// Sendstring lookup tables for Estonian layouts

#pragma once

#include "keymap_estonian.h"
#include "quantum"

// clang-format off

const uint8_t ascii_to_shift_lut[16] PROGMEM = {
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),

    KCLUT_ENTRY(0, 1, 1, 1, 0, 1, 1, 0),
    KCLUT_ENTRY(1, 1, 1, 0, 0, 0, 0, 1),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 1, 1, 0, 1, 1, 1),
    KCLUT_ENTRY(0, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 0, 0, 0, 0, 1),
    KCLUT_ENTRY(1, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0)
};

const uint8_t ascii_to_altgr_lut[16] PROGMEM = {
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),

    KCLUT_ENTRY(0, 0, 0, 0, 1, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(1, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 1, 1, 1, 1, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 1, 1, 1, 1, 0)
};

const uint8_t ascii_to_keycode_lut[128] PROGMEM = {
    // NUL   SOH      STX      ETX      EOT      ENQ      ACK      BEL
    XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // BS    TAB      LF       VT       FF       CR       SO       SI
    KC_BSPC, KC_TAB,  KC_ENT,  XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // DLE   DC1      DC2      DC3      DC4      NAK      SYN      ETB
    XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // CAN   EM       SUB      ESC      FS       GS       RS       US
    XXXXXXX, XXXXXXX, XXXXXXX, KC_ESC,  XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,

    //       !        "        #        $        %        &        '
    KC_SPC,  EE_1,    EE_2,    EE_3,    EE_4,    EE_5,    EE_6,    EE_QUOT,
    // (     )        *        +        ,        -        .        /
    EE_8,    EE_9,    EE_QUOT, EE_PLUS, EE_COMM, EE_MINS, EE_DOT,  EE_7,
    // 0     1        2        3        4        5        6        7
    EE_0,    EE_1,    EE_2,    EE_3,    EE_4,    EE_5,    EE_6,    EE_7,
    // 8     9        :        ;        <        =        >        ?
    EE_8,    EE_9,    EE_DOT,  EE_COMM, EE_LABK, EE_0,    EE_LABK, EE_PLUS,
    // @     A        B        C        D        E        F        G
    EE_2,    EE_A,    EE_B,    EE_C,    EE_D,    EE_E,    EE_F,    EE_G,
    // H     I        J        K        L        M        N        O
    EE_H,    EE_I,    EE_J,    EE_K,    EE_L,    EE_M,    EE_N,    EE_O,
    // P     Q        R        S        T        U        V        W
    EE_P,    EE_Q,    EE_R,    EE_S,    EE_T,    EE_U,    EE_V,    EE_W,
    // X     Y        Z        [        \        ]        ^        _
    EE_X,    EE_Y,    EE_Z,    EE_8,    EE_PLUS, EE_9,    EE_ADIA, EE_MINS,
    // `     a        b        c        d        e        f        g
    EE_ACUT, EE_A,    EE_B,    EE_C,    EE_D,    EE_E,    EE_F,    EE_G,
    // h     i        j        k        l        m        n        o
    EE_H,    EE_I,    EE_J,    EE_K,    EE_L,    EE_M,    EE_N,    EE_O,
    // p     q        r        s        t        u        v        w
    EE_P,    EE_Q,    EE_R,    EE_S,    EE_T,    EE_U,    EE_V,    EE_W,
    // x     y        z        {        |        }        ~        DEL
    EE_X,    EE_Y,    EE_Z,    EE_7,    EE_LABK, EE_0,    EE_CARN, KC_DEL
};
