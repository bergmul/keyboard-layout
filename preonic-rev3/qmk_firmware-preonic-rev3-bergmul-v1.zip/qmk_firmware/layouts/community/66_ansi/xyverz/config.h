#pragma once

#define TAPPING_TERM 600 // ms
#undef RGBLIGHT_HUE_STEP
#define RGBLIGHT_HUE_STEP 8
